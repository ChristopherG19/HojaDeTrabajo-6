/**
 * Universidad del Valle de Guatemala
 * Algoritmos y estructura de datos - Sección 10
 * Hoja de trabajo#6
 * @author Christopher García 20541
 * @author Maria Fernanda Argueta 20458
 */
import java.io.File;
import java.util.*;

public class Main{

    public static void main(String[] args) {
        
      Scanner scanner = new Scanner(System.in);
      int conMon = 0;
      int contra = 0;
      int conhec = 0;
      MapFactory<String, Cartas> TipoM = new MapFactory<String, Cartas>();
      Mapas<String, Cartas> CajaCartas;
      Mapas<String, Cartas> CajaCartasUsuario;
      ArrayList<String> CartasArchivo = leerArchivo("cards_desc.txt");

      System.out.println("\n---> Bienvenido(a) nuevo(a) usuario(a) <---");
      System.out.println("Antes de comenzar deberas escoger la implementacion de Map\n");

      System.out.println("---> Implementaciones disponibles <---");
      System.out.println("1.) HashMap");
      System.out.println("2.) TreeMap");
      System.out.println("3.) LinkedHashMap\n");
      System.out.print("Eleccion: ");
      int eleccion = 0;

      try {
        eleccion = scanner.nextInt();
        if (eleccion <= 0){
          System.out.println("\nFuera de rango\n");
        } else if (eleccion > 3){
          System.out.println("\nFuera de rango\n");
        } 

      } catch (Exception e) {
        System.out.println("Error, ingreso de opcion incorrecta");
      }

      System.out.println();
      CajaCartas = TipoM.GetTypeofMap(eleccion);
      CajaCartasUsuario = TipoM.GetTypeofMap(eleccion);

      for(String carta: CartasArchivo){
        String NombreC = carta.split("\\|")[0];
        String TipoC = carta.split("\\|")[1];
        Cartas cartaNueva = new Cartas(NombreC, TipoC);
        CajaCartas.Put(NombreC, cartaNueva);
      }
      System.out.println();

      boolean Modificador = true;

      while(Modificador){

        System.out.println("---> Opciones disponibles <---");
        System.out.println();
        System.out.println("1.) Agregar una carta a tu coleccion");
        System.out.println("2.) Buscar una carta especifica");
        System.out.println("3.) Información de cada carta en tu coleccion");
        System.out.println("4.) Información de cada carta en tu coleccion ordenadas por tipo");
        System.out.println("5.) Información de cada carta existente");
        System.out.println("6.) Información de cada carta existente ordenadas por tipo");
        System.out.println("7.) Salir del programa");
        
        System.out.print("\nOpcion a elegir: ");
        int eleccion2 = 0;

        boolean Comprobante = true;
    
        while(Comprobante){
          try {
            eleccion2 = scanner.nextInt();
            if (eleccion2 < 1 || eleccion2 > 7){
              System.out.println("\nFuera de rango\n");
            } else {
              Comprobante = false;
            }
          } catch (Exception e) {
            System.out.println(e);
            System.out.println("Error, ingreso de opcion incorrecta");
          }
        }
    
        String NombreCartaUsuario;

        if(eleccion2 == 1){

          Scanner scan = new Scanner(System.in);
          System.out.print("\nNombre de la carta que deseas agregar: ");
          NombreCartaUsuario = scan.nextLine();

          if(CajaCartas.ContainsKey(NombreCartaUsuario)){
  
            if(!CajaCartasUsuario.ContainsKey(NombreCartaUsuario)){
              CajaCartasUsuario.Put(NombreCartaUsuario, CajaCartas.GetB(NombreCartaUsuario));
            } else {
              CajaCartasUsuario.GetB(NombreCartaUsuario).setNumCarta(1);
            }
            System.out.println("\nListo, has aumentado tu coleccion con esta nueva carta");
            System.out.println("Informacion agregada a tu coleccion\n" + CajaCartasUsuario.GetB(NombreCartaUsuario).toString());
            System.out.println();
  
          } else {
            System.out.println("\nLo siento, la carta no se encuentra dentro de las cartas disponibles");
          }
  
        } else if (eleccion2 == 2){
  
          Scanner scan2 = new Scanner(System.in);
          System.out.print("\nNombre de la carta que deseas buscar: ");
          NombreCartaUsuario = scan2.nextLine();
          if(CajaCartasUsuario.ContainsKey(NombreCartaUsuario)){
            System.out.println("\nHemos encontrado lo siguiente... ");
            System.out.println();
            System.out.println("Tipo: "+ CajaCartas.GetB(NombreCartaUsuario).getTipo());
            System.out.println();
          } else {
            System.out.println("\nLo sentimos, ninguna carta coincide en tu coleccion"); 
          }
  
        } else if (eleccion2 == 3){
          if(CajaCartasUsuario.IsEmpty() == true){
            System.out.println("Lo sentimos, tu coleccion está vacia");
          }
  
          for(String CartaMagica: CajaCartasUsuario.Keyset()){
            System.out.println("\nNombre de la carta: " + CartaMagica);
            System.out.println("Tipo de la carta: " + CajaCartasUsuario.GetB(CartaMagica).getTipo());
            System.out.println("Cantidad de la carta: " + CajaCartasUsuario.GetB(CartaMagica).getNumCarta());
          }
          System.out.println();
  
        } else if (eleccion2 == 4){
  
          if(!CajaCartasUsuario.IsEmpty()){
            ArrayList<Cartas> CartasMagicas = new ArrayList<Cartas>(CajaCartasUsuario.Valores());
            CartasMagicas.sort(new Verificador());
            for(Cartas cartaunica : CartasMagicas){
              System.out.println(cartaunica.toString());
            }
          } else {
            System.out.println("Tu coleccion se encuentra vacia");
          }
          System.out.println();
  
        } else if (eleccion2 == 5){

          for(Cartas cartamagica : CajaCartas.Valores()){
            System.out.println(cartamagica);
          }
          System.out.println();
  
        } else if (eleccion2 == 6){
  
          ArrayList<Cartas> CartasMagicas = new ArrayList<Cartas>(CajaCartas.Valores());
          CartasMagicas.sort(new Verificador());
          for(Cartas cartaunica : CartasMagicas){
            System.out.println(cartaunica.toString());
          }
          System.out.println();
  
        } else if (eleccion2 == 7){
          System.out.println("\nQue tengas un excelente dia :D\n");

          System.out.println();
          for(String linea : CartasArchivo){
            String[] linea2 = linea.split("\\|");
            List<String> Datos = Arrays.asList(linea2);

            if(Datos.get(1).equals("Monstruo")){
              conMon++;
            }else if(Datos.get(1).equals("Trampa")){
              contra++;
            } else if(Datos.get(1).equals("Hechizo")){
              conhec++;
            }     
          }

          System.out.println("\t-----> Cartas totales <-----");
          System.out.println();
          System.out.println("Carta Tipo Monstruo: " +conMon+" en total");
          System.out.println("Carta Tipo Trampa: " +contra+" en total");
          System.out.println("Carta Tipo Hechizo: "+conhec+" en total");

          System.out.println();
          Modificador = false;
        }
      }

      scanner.close();
    }

    /**
     * Método leerArchivo
     * @param nombreArchivo: Nombre del archivo a evaluar
     * @return: ArrayList con cada linea del archivo
     */
    public static ArrayList<String> leerArchivo(String nombreArchivo){

        ArrayList<String> Info = new ArrayList<String>();
        try {
          File Archivo = new File(nombreArchivo);
          Scanner Lector = new Scanner(Archivo);
    
          while(Lector.hasNextLine()){
            String Line = Lector.nextLine();
            Info.add(Line);
          }
          Lector.close();
        } catch (Exception e){
          System.out.println("Error! Archivo no encontrado");
          e.printStackTrace();
        }
        return Info;
      }
  
}