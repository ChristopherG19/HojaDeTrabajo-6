/**
 * Universidad del Valle de Guatemala
 * Algoritmos y estructura de datos - Sección 10
 * Hoja de trabajo#6
 * @author Christopher García 20541
 * @author Maria Fernanda Argueta 20458
 */
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.Collection;

public class LinkedHashMapC<A,B> extends LinkedHashMap<A,B> implements Mapas<A,B>  {
    
    private static final long serialVersionUID = 1L;

    @Override
    public Set<A> Keyset() {
        return keySet();
    }

    @Override
    public void Remove(A Dato) {
        remove(Dato);
    }

    @Override
    public void Put(A Dato, B info) {
        put(Dato, info);
        
    }

    @Override
    public boolean ContainsKey(A Dato) {
        return containsKey(Dato);
    }

    @Override
    public boolean ContainsValue(B info) {
        return containsValue(info);
    }

    @Override
    public B GetB(A Dato) {
        return get(Dato);
    }

    @Override
    public boolean IsEmpty() {
        return isEmpty();
    }

    @Override
    public int Tamaño() {
        return size();
    }

    @Override
    public void Reemplazo(A Dato, B info) {
        replace(Dato, info);
    }

    @Override
    public Collection<B> Valores() {
        return values();
    }
}
