/**
 * Universidad del Valle de Guatemala
 * Algoritmos y estructura de datos - Sección 10
 * Hoja de trabajo#6
 * @author Christopher García 20541
 * @author Maria Fernanda Argueta 20458
 */
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapFactory<A, B> {

    public Map<A, B> GetTypeofMap(int entry) {
        // seleccion del tipo de mapa a utilizar:
        if (entry == 1){
            return new HashMap<A, B>(); 
        }
        else if(entry == 2){
            return new TreeMap<A, B>();
        }
        else if(entry == 3){
            return new LinkedHashMap<A, B>();
        }
        else{
            System.out.println("Error!! Se utilizar HashMap por defecto");
            return new HashMap<A, B>();
        }
    }
      
}
