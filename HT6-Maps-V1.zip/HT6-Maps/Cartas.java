/**
 * Universidad del Valle de Guatemala
 * Algoritmos y estructura de datos - Sección 10
 * Hoja de trabajo#6
 * @author Christopher García 20541
 * @author Maria Fernanda Argueta 20458
 */

public class Cartas implements Comparable<Cartas>{
    
    private String NombreC;
    private String TipoC;
    private int NumCarta = 0;

    public Cartas(String Nombre, String Tipo){
        NombreC = Nombre;
        TipoC = Tipo;
    }

    public String getNombre(){
        return NombreC;
    }

    public String getTipo(){
        return TipoC;
    }

    public int getNumCarta() {
        return NumCarta;
    }

    public void setNumCarta(int numCarta) {
        NumCarta = numCarta;
    }

    @Override
    public int compareTo(Cartas o) {
        String NombreCom = o.getNombre();
        return NombreC.compareTo(NombreCom);
    }

    public String toString(){
        return "\nNombre de la carta: " + NombreC + "\nTipo: " + TipoC + "\nNo. "+ NumCarta;
    }
}
