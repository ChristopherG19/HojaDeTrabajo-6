/**
 * Universidad del Valle de Guatemala
 * Algoritmos y estructura de datos - Sección 10
 * Hoja de trabajo#6
 * @author Christopher García 20541
 * @author Maria Fernanda Argueta 20458
 */
import java.io.File;
import java.util.*;

public class Main{

    public static void main(String[] args) {
        
      boolean Verificador = true;
      Scanner scanner = new Scanner(System.in);
      MapFactory<String, String> TipoM = new MapFactory<String, String>();
      ArrayList<String> Cartas = leerArchivo("cards_desc.txt");

      System.out.println("\n---> Bienvenido(a) nuevo(a) usuario(a) <---");
      System.out.println("Antes de comenzar deberas escoger la implementacion de Map\n");

      while(Verificador){

        System.out.println("---> Implementaciones disponibles <---");
        System.out.println("1.) HashMap");
        System.out.println("2.) TreeMap");
        System.out.println("3.) LinkedHashMap\n");
        System.out.print("Eleccion: ");
        int eleccion = scanner.nextInt();
        if (eleccion == 4){
          Verificador = false;
        }
        System.out.println();
        System.out.println(eleccion);
        TipoM.GetTypeofMap(eleccion);
        System.out.println();

      }


      int conMon = 0;
      int contra = 0;
      int conhec = 0;
      for(String linea : Cartas){

        String[] linea2 = linea.split("\\|");
        String NombreCarta = linea.split("\\|")[0];
        String TipoCarta = linea.split("\\|")[1];
        System.out.println(NombreCarta);
        System.out.println(TipoCarta);
        List<String> Datos = Arrays.asList(linea2);

        if(Datos.get(1).equals("Monstruo")){
          System.out.println(Datos.get(0) + " " + Datos.get(1));
          conMon++;
        }else if(Datos.get(1).equals("Trampa")){
          //System.out.println(Datos.get(0) + " " + Datos.get(1));
          contra++;
        } else if(Datos.get(1).equals("Hechizo")){
          //System.out.println(Datos.get(0) + " " + Datos.get(1));
          conhec++;
        }
            
      }
      System.out.println("Carta tipo monstruo: " +conMon+" en total");
      System.out.println("Carta tipo trampa: " +contra+" en total");
      System.out.println("Carta tipo hechizo: "+conhec+" en total");

      scanner.close();
    }

    public static ArrayList<String> leerArchivo(String nombreArchivo){

        ArrayList<String> Info = new ArrayList<String>();
    
        try {
    
          File Archivo = new File(nombreArchivo);
          Scanner Lector = new Scanner(Archivo);
    
          while(Lector.hasNextLine()){
            String Line = Lector.nextLine();
            Info.add(Line);
          }
          Lector.close();
    
        } catch (Exception e){
          System.out.println("Error! Archivo no encontrado");
          e.printStackTrace();
        }
    
        return Info;
      }
  
}